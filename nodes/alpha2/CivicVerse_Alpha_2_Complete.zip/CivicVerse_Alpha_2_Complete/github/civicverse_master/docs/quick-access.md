# 🧭 Quick Access

- 📜 [Deployment Statement](https://github.com/Civicverse/Civicverse/blob/main/nodes/vanta1/deployment-statement.md)
- ⚙️ [Protocol Integrity Doctrine](https://github.com/Civicverse/Civicverse/blob/main/nodes/vanta1/protocol-integrity-doctrine.md)
- 🗂️ [All Field Logs](https://github.com/Civicverse/Civicverse/tree/main/nodes/vanta1/logs)
- 🏛️ [Ethics Council Framework](https://github.com/Civicverse/Civicverse/blob/main/nodes/vanta1/ethics-council.md)
