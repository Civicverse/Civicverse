#!/bin/bash
sudo apt update && sudo apt install -y git python3 python3-pip docker.io docker-compose ffmpeg nodejs npm
cd civicverse-ultimate-ai-full
docker-compose up -d
python3 ai_core/agent.py