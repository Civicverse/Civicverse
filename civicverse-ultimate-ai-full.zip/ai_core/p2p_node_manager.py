class P2PNodeManager(NodeManager):
    def connect_peers(self, peer_list):
        self.peers = peer_list
        print(f"Connected to {len(peer_list)} peers")
    def broadcast_task(self, task):
        print(f"Broadcasted task: {task}")
    def sync_state(self):
        print("State synchronized across network")