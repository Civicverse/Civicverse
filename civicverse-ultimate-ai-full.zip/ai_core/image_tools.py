from PIL import Image, ImageDraw
class ImageTools:
    def generate(self, plan):
        img = Image.new("RGB", (640,480), color=(73,109,137))
        d = ImageDraw.Draw(img)
        d.text((10,10), "Image placeholder", fill=(255,255,0))
        img.save("output.png")
        print("Image generated")