class LLMInterface:
    def generate(self, prompt):
        return f"Generated plan for: {prompt}"