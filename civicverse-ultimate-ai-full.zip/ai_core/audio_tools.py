from pydub import AudioSegment
from pydub.generators import Sine
class AudioTools:
    def generate(self, plan):
        sine = Sine(440).to_audio_segment(duration=2000)
        sine.export("output.wav", format="wav")
        print("Audio generated")