from moviepy.editor import TextClip, concatenate_videoclips
class VideoTools:
    def generate(self, plan):
        clip = TextClip("Video placeholder", fontsize=70, color="white", size=(640,480)).set_duration(2)
        clip.write_videofile("output.mp4")
        print("Video generated")