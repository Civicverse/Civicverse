from planner import Planner
from executor import Executor
from node_manager import NodeManager
from p2p_node_manager import P2PNodeManager
from ethics_guard import EthicsGuard
from llm_interface import LLMInterface
from video_tools import VideoTools
from image_tools import ImageTools
from audio_tools import AudioTools
from code_tools import CodeTools

def main():
    llm = LLMInterface()
    planner = Planner(llm)
    executor = Executor()
    ethics = EthicsGuard()
    nodes = NodeManager()
    p2p = P2PNodeManager()

    p2p.connect_peers(["127.0.0.1"])

    task = "Deploy new node, generate content, update economy"
    plan = planner.create_plan(task)

    if ethics.check(plan):
        nodes.deploy_local_node()
        p2p.broadcast_task(plan)
        nodes.replicate_nodes()
        executor.execute(plan)
    else:
        print("Task blocked by ethics guard.")

if __name__ == "__main__":
    main()