class Planner:
    def __init__(self, llm):
        self.llm = llm
    def create_plan(self, task_description):
        return self.llm.generate(f"Decompose task: {task_description}")