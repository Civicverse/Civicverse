class EthicsGuard:
    def check(self, plan):
        return True