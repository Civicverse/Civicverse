class Executor:
    def execute(self, plan):
        print(f"Executing plan: {plan}")