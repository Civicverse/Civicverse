class CodeTools:
    def generate(self, plan):
        with open("output.py", "w") as f:
            f.write("# Code placeholder")
        print("Code generated")